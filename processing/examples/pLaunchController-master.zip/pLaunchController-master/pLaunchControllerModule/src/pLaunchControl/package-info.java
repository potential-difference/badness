/**
 * Library implementation for Launch Control controllers.
 */
package pLaunchControl;